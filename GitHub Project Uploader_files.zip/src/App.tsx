import  { Toaster } from 'react-hot-toast';
import { Header } from './components/Header';
import { UploadForm } from './components/UploadForm';

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Toaster position="top-right" />
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900">Upload Your Project</h2>
          <p className="mt-2 text-gray-600">
            Easily upload your project files directly to your GitHub repository
          </p>
        </div>
        
        <UploadForm />
      </main>
    </div>
  );
}

export default App;
 
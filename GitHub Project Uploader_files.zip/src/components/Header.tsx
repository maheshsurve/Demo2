import  { Github } from 'lucide-react';

export const Header = () => {
  return (
    <header className="w-full bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Github className="w-8 h-8" />
            <h1 className="text-2xl font-bold text-gray-900">GitHub Uploader</h1>
          </div>
        </div>
      </div>
    </header>
  );
};
 
import  { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { Upload, FolderOpen, AlertCircle, Info } from 'lucide-react';
import toast from 'react-hot-toast';
import { uploadToGithub } from '../utils/github';

export const UploadForm = () => {
  const [repoName, setRepoName] = useState('');
  const [token, setToken] = useState('');
  const [uploading, setUploading] = useState(false);
  const [files, setFiles] = useState<File[]>([]);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    setFiles(acceptedFiles);
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop
  });

  const resetForm = () => {
    setRepoName('');
    setToken('');
    setFiles([]);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!repoName || !token || files.length === 0) {
      toast.error('Please fill in all fields and select files');
      return;
    }

    if (!repoName.includes('/')) {
      toast.error('Repository name should be in format username/repository');
      return;
    }

    if (!token.startsWith('ghp_') && !token.startsWith('github_pat_')) {
      toast.error('Invalid GitHub token format. Token should start with "ghp_" or "github_pat_"');
      return;
    }

    setUploading(true);
    
    try {
      await toast.promise(
        uploadToGithub(repoName, token, files),
        {
          loading: 'Verifying access and uploading files...',
          success: 'Files uploaded successfully!',
          error: (err) => err instanceof Error ? err.message : 'Upload failed'
        }
      );
      
      // Clear form after successful upload
      resetForm();
    } catch (error) {
      console.error('Upload error:', error);
    } finally {
      setUploading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6 max-w-2xl mx-auto">
      <div className="space-y-2">
        <label htmlFor="repo" className="block text-sm font-medium text-gray-700">
          Repository Name
        </label>
        <input
          id="repo"
          type="text"
          value={repoName}
          onChange={(e) => setRepoName(e.target.value)}
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          placeholder="username/repository"
        />
        <div className="flex items-center space-x-1 text-xs text-gray-500">
          <Info className="w-3 h-3" />
          <span>Enter in format: username/repository-name</span>
        </div>
      </div>

      <div className="space-y-2">
        <label htmlFor="token" className="block text-sm font-medium text-gray-700">
          GitHub Token
        </label>
        <div className="relative">
          <input
            id="token"
            type="password"
            value={token}
            onChange={(e) => setToken(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="ghp_xxxxxxxxxxxx"
          />
          <div className="mt-2 text-xs space-y-1">
            <p className="text-gray-500">
              Need a token? <a href="https://github.com/settings/tokens/new" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:text-blue-800">Create one here</a> with 'repo' scope
            </p>
            <p className="flex items-center space-x-1 text-gray-500">
              <Info className="w-3 h-3" />
              <span>Token must have 'repo' scope for repository access</span>
            </p>
          </div>
        </div>
      </div>

      <div className="space-y-2">
        <label className="block text-sm font-medium text-gray-700">
          Project Files
        </label>
        <div
          {...getRootProps()}
          className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors
            ${isDragActive ? 'border-blue-500 bg-blue-50' : 'border-gray-300 hover:border-gray-400'}`}
        >
          <input {...getInputProps()} />
          <FolderOpen className="mx-auto h-12 w-12 text-gray-400" />
          {isDragActive ? (
            <p className="mt-2 text-sm text-gray-600">Drop the files here...</p>
          ) : (
            <p className="mt-2 text-sm text-gray-600">
              Drag & drop files here, or click to select files
            </p>
          )}
        </div>
        {files.length > 0 && (
          <div className="mt-4">
            <h4 className="text-sm font-medium text-gray-700">Selected files:</h4>
            <ul className="mt-2 text-sm text-gray-500">
              {files.map((file) => (
                <li key={file.name} className="flex items-center space-x-2">
                  <span>📄</span>
                  <span>{file.name}</span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>

      <div className="flex items-center space-x-2 text-sm text-gray-600 bg-yellow-50 p-4 rounded-lg">
        <AlertCircle className="w-5 h-5 text-yellow-500 flex-shrink-0" />
        <p>Make sure you have the necessary permissions to upload to this repository and your token has the 'repo' scope</p>
      </div>

      <button
        type="submit"
        disabled={uploading}
        className={`w-full flex items-center justify-center space-x-2 px-4 py-2 rounded-lg text-white font-medium
          ${uploading
            ? 'bg-gray-400 cursor-not-allowed'
            : 'bg-blue-600 hover:bg-blue-700'
          }`}
      >
        <Upload className="w-5 h-5" />
        <span>{uploading ? 'Uploading...' : 'Upload to GitHub'}</span>
      </button>
    </form>
  );
};
 